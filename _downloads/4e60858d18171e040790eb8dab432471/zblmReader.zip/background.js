// const TITLE_APPLY = "驿窗零蓝";
// const TITLE_REMOVE = "驿窗零蓝";
const APPLICABLE_PROTOCOLS = ["http:", "https:"];


function toggleCSS(tab) {

  browser.storage.local.get().then((data)=>{
    setstatus(!data.status)
  })

}


function protocolIsApplicable(url) {
  const protocol = (new URL(url)).protocol;
  return APPLICABLE_PROTOCOLS.includes(protocol);
}

function setstatus(status){
  if (status) {
    browser.browserAction.setIcon({ path: "icons/on.svg" });
    browser.browserSettings.overrideDocumentColors
      .set({ value: "always" })
      .then(logResult);
    
  } else {
    browser.browserAction.setIcon({ path: "icons/off.svg" });
    browser.browserSettings.overrideDocumentColors
      .set({ value: "high-contrast-only" })
      .then(logResult);
  }
  browser.storage.local.set({
    status: status
  });
}

function initializePageAction(tab) {
  if (protocolIsApplicable(tab.url)) {
    browser.storage.local.get().then((data)=>{
      console.log('in init page')
      console.log(data.status)
      if(data.status){
        setstatus(data.status)
      }else{
        setstatus(false)
      }
    })
  }
}


let gettingAllTabs = browser.tabs.query({});
gettingAllTabs.then((tabs) => {
  for (let tab of tabs) {
    initializePageAction(tab);
  }
});


browser.tabs.onUpdated.addListener((id, changeInfo, tab) => {
  initializePageAction(tab);
});


browser.browserAction.onClicked.addListener(toggleCSS);


function logResult(result) {
  console.log(`Setting was modified: ${result}`);
}



